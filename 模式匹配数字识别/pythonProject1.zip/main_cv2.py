import os

import cv2

# 第一步：从模板文件夹中读取模板
templates = {}
for i in range(10):
    img = cv2.imread(f'templates/{i}.png', 0)  # 这里假设你的模板图片是黑白的，并且文件名是数字.png
    templates[i] = img

# 第二步：从测试文件夹中读取测试图片，并进行匹配
for filename in os.listdir('tests'):
    test_img = cv2.imread(f'tests/{filename}', 0)

    max_similarity = -1
    predicted_digit = -1
    # 与所有模板进行匹配
    for digit, template in templates.items():
        # 使用模板匹配
        res = cv2.matchTemplate(test_img, template, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        if max_val > max_similarity:
            max_similarity = max_val
            predicted_digit = digit

    print(f'The predicted digit for {filename} is {predicted_digit}, similarity is {max_similarity}.')
