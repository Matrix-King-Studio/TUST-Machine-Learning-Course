import os

from PIL import Image, ImageDraw, ImageFont

# 创建模板和测试文件夹
if not os.path.exists('templates'):
    os.makedirs('templates')
if not os.path.exists('tests'):
    os.makedirs('tests')

# 生成宋体的模板图片
for i in range(10):
    img = Image.new('RGB', (32, 32), color=(255, 255, 255))
    d = ImageDraw.Draw(img)
    font = ImageFont.truetype('simsun.ttc', 15)  # 请替换为你的宋体字体文件的路径
    # 多次绘制文本以产生加粗的效果
    for j in range(-1, 1):
        for k in range(-1, 1):
            d.text((10+j, 10+k), str(i), font=font, fill=(0, 0, 0))
    # d.text((10, 10), str(i), font=font, fill=(0, 0, 0))
    img = img.convert('L')  # 转换为灰度模式
    img.save(f'templates/{i}.png')

# 生成Furore的测试图片
for i in range(10):
    img = Image.new('RGB', (32, 32), color=(255, 255, 255))
    d = ImageDraw.Draw(img)
    font = ImageFont.truetype('Furore/Furore.otf', 15)  # 请替换为你的Furore字体文件的路径
    d.text((10, 10), str(i), font=font, fill=(0, 0, 0))
    img = img.convert('L')  # 转换为灰度模式
    img.save(f'tests/{i}.png')
