import numpy as np
import os
from PIL import Image


def load_image(path):
    return np.array(Image.open(path))


# 第一步：从模板文件夹中读取模板
templates = {}
for i in range(10):
    img = load_image(f'templates/{i}.png')
    templates[i] = img

# 第二步：从测试文件夹中读取测试图片，并进行匹配
for filename in os.listdir('tests'):
    test_img = load_image(f'tests/{filename}')

    min_distance = float('inf')
    predicted_digit = -1
    # 与所有模板进行匹配
    for digit, template in templates.items():
        # 计算欧氏距离
        distance = np.sqrt(np.sum((test_img - template) ** 2))
        # print(f"\t{filename} 与 {digit} 的距离为：{distance}")
        if distance < min_distance:
            min_distance = distance
            predicted_digit = digit

    print(f'The predicted digit for {filename} is {predicted_digit}, distance is {min_distance}.')
